# GoDaddy mailbox helper stub (manual UI on iPhone)
