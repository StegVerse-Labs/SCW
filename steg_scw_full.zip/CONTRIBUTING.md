# Contributing
Use PRs, Conventional Commits, and add `Signed-off-by:` (use `git commit -s`).
