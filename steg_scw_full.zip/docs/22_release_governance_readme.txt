
Release & Commit Governance
===========================
- DCO: use `git commit -s` to append `Signed-off-by:` automatically.
- Conventional Commits: feat|fix|docs|chore|refactor|test|ci|build
- semantic-release creates versions/tags/CHANGELOG on main.
