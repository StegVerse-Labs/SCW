# GoDaddy DNS MX/SPF/DMARC stub — see provider docs
